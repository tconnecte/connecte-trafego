import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function FaqSection() {
  const faqs = [
    {
      question: "O que exatamente é o Connecte Tráfego?",
      answer:
        "É um sistema de tráfego pago com metodologia própria, que transforma campanhas improvisadas em operações de aquisição estruturadas, orientadas por dados, planejamento e performance.",
    },
    {
      question: "Isso é só impulsionamento de post?",
      answer:
        "Não. Aqui você recebe diagnóstico, arquitetura estratégica, planejamento completo e ativação de campanhas com lógica de funil validada. Não fazemos testes aleatórios.",
    },
    {
      question: "Preciso entender de tráfego para contratar?",
      answer:
        "Não. O serviço é feito para empresários, profissionais e marcas que querem resultados reais, sem ter que dominar as ferramentas. Nós cuidamos de toda a parte técnica.",
    },
    {
      question: "Tem contrato de fidelidade ou multa?",
      answer:
        "Não. O plano de Audiência é mensal. O Combo (Audiência + Relacionamento) tem duração mínima de 6 meses, com condições específicas por ser estratégico.",
    },
    {
      question: "Em quanto tempo posso ver resultados?",
      answer:
        "Depende da estrutura atual do seu negócio, mas normalmente os primeiros resultados aparecem nas primeiras semanas. O foco, no entanto, é construção consistente e escalável.",
    },
    {
      question: "Serve para qualquer tipo de negócio?",
      answer:
        "Trabalhamos principalmente com negócios nas áreas de saúde, beleza, educação, infoprodutos e empresas locais. Mas qualquer empresa que venda online pode se beneficiar.",
    },
    {
      question: "Vocês entregam criativos, vídeos ou landing pages?",
      answer:
        "Não. Nossa entrega é 100% estratégica e voltada para mídia paga. Criativos e páginas devem ser produzidos pelo cliente, parceiro ou contratado à parte.",
    },
    {
      question: "E se eu quiser começar pequeno, posso?",
      answer:
        "Sim. O plano Audiência (197€) é ideal para quem quer iniciar, testar a estrutura e crescer de forma inteligente. Você pode evoluir para o combo depois.",
    },
    {
      question: "Já rodaram esse método com outros clientes?",
      answer:
        "Sim. Já aplicamos o método ARVE em mais de 60 projetos, em 6 países, com validações em diferentes estágios de maturidade digital. O sistema é testado e aprovado.",
    },
    {
      question: "Como faço para contratar agora?",
      answer:
        "Simples. Clique no botão da página, fale com nosso time pelo WhatsApp e escolha o plano mais adequado ao seu momento. Nós cuidamos do resto.",
    },
  ]

  return (
    <section id="faq" className="w-full py-16 md:py-24 bg-secondary">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-geoform text-foreground">Perguntas Frequentes</h2>
          <p className="text-lg font-poppins text-foreground max-w-3xl">Tire suas dúvidas sobre o Connecte Tráfego.</p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-b border-muted">
                <AccordionTrigger className="py-4 font-geoform text-lg text-foreground text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="py-4 font-poppins text-foreground">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  )
}

