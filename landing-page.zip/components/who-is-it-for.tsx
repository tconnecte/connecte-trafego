import { Users, Target, BarChart3, AlertTriangle } from "lucide-react"

export default function WhoIsItFor() {
  const profiles = [
    {
      icon: Users,
      title: "Marcas iniciando posicionamento digital",
      description:
        "Ideal para quem está começando a construir presença online e precisa de direcionamento estratégico.",
    },
    {
      icon: Target,
      title: "Negócios que querem captar leads com estrutura",
      description: "Para empresas que buscam uma abordagem sistemática na geração de leads qualificados.",
    },
    {
      icon: BarChart3,
      title: "Empresas que buscam performance com dados",
      description: "Perfeito para quem valoriza decisões baseadas em métricas e resultados mensuráveis.",
    },
    {
      icon: AlertTriangle,
      title: "Profissionais cansados de tráfego &quot;tentativa e erro&quot;",
      description: "Para quem já investiu em anúncios sem método e busca previsibilidade nos resultados.",
    },
  ]

  return (
    <section className="w-full py-16 md:py-24 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-geoform text-foreground">Para Quem é</h2>
          <p className="text-lg font-poppins text-foreground max-w-3xl">
            O Connecte Tráfego foi desenvolvido para atender diferentes perfis de negócios.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {profiles.map((profile, index) => (
            <div key={index} className="flex items-start space-x-4 p-6 bg-white rounded-lg shadow-sm">
              <div className="p-2 bg-secondary rounded-full flex-shrink-0">
                <profile.icon className="h-6 w-6 text-foreground" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-geoform text-foreground mb-2">{profile.title}</h3>
                <p className="font-poppins text-foreground">{profile.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

