"use client"

import { Button } from "@/components/ui/button"
import { MessageSquare } from "lucide-react"

export default function FinalCta() {
  return (
    <section className="w-full py-16 md:py-24 bg-primary">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold font-geoform text-primary-foreground max-w-3xl">
            Pronto para levar sua operação de tráfego a outro nível?
          </h2>
          <Button
            size="lg"
            variant="outline"
            className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 border-primary-foreground font-poppins px-8 py-6 text-base rounded-md"
            onClick={() => window.open("https://wa.me/message/YOUR_WHATSAPP_NUMBER", "_blank")}
          >
            <MessageSquare className="mr-2 h-5 w-5" />
            Falar com a Tconnecte agora
          </Button>
        </div>
      </div>
    </section>
  )
}

