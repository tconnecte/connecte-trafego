import { ArrowRight, FileText, BarChart3, Zap, PieChart } from "lucide-react"

export default function HowItWorks() {
  const steps = [
    {
      icon: FileText,
      title: "Kickoff estratégico",
      description: "Reunião inicial para entender objetivos e alinhar expectativas.",
    },
    {
      icon: PieChart,
      title: "Diagnóstico + Arquitetura do Funil",
      description: "Análise completa e planejamento da estrutura de aquisição.",
    },
    {
      icon: Zap,
      title: "Ativação das campanhas",
      description: "Implementação das estratégias definidas nas plataformas.",
    },
    {
      icon: BarChart3,
      title: "Relatórios de performance",
      description: "Acompanhamento de resultados e otimizações contínuas.",
    },
  ]

  return (
    <section className="w-full py-16 md:py-24 bg-secondary">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-geoform text-foreground">Como Funciona</h2>
          <p className="text-lg font-poppins text-foreground max-w-3xl">
            Conheça o processo de implementação do Connecte Tráfego.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div key={index} className="flex flex-col items-center text-center space-y-4 relative">
              <div className="p-4 bg-background rounded-full">
                <step.icon className="h-8 w-8 text-foreground" />
              </div>
              <h3 className="text-xl font-bold font-geoform text-foreground">{step.title}</h3>
              <p className="font-poppins text-foreground">{step.description}</p>

              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-8 left-[calc(100%-16px)] transform -translate-x-1/2">
                  <ArrowRight className="h-6 w-6 text-foreground" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

