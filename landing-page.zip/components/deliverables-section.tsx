import { Check, X } from "lucide-react"

export default function DeliverablesSection() {
  const includes = [
    "Diagnóstico estratégico",
    "Arquitetura do funil",
    "Segmentações avançadas",
    "Definição de KPIs",
    "Criação de campanhas",
    "Relatórios de performance",
  ]

  const excludes = [
    "Criação de site ou landing pages",
    "Produção de criativos (imagens/vídeos)",
    "Gestão de redes sociais",
    "Configuração de automações",
  ]

  return (
    <section className="w-full py-16 md:py-24 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-12">
          <h2 className="text-3xl md:text-4xl font-bold font-geoform text-foreground text-center">
            Entregas e Exclusões
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl">
            {/* Includes */}
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <h3 className="text-xl font-bold font-geoform text-foreground mb-6">O que inclui:</h3>
              <ul className="space-y-4">
                {includes.map((item, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="font-poppins text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Excludes */}
            <div className="bg-white p-8 rounded-lg shadow-sm">
              <h3 className="text-xl font-bold font-geoform text-foreground mb-6">O que não inclui:</h3>
              <ul className="space-y-4">
                {excludes.map((item, index) => (
                  <li key={index} className="flex items-start">
                    <X className="h-5 w-5 text-red-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="font-poppins text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

