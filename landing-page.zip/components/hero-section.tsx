"use client"

import { Button } from "@/components/ui/button"
import { MessageSquare } from "lucide-react"

export default function HeroSection() {
  return (
    <section className="w-full py-16 md:py-24 lg:py-32 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center">
          <div className="space-y-6 max-w-4xl">
            <h1 className="text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold tracking-tighter font-geoform text-foreground leading-tight">
              Transforme seus anúncios em uma operação de aquisição estratégica.
            </h1>
            <p className="text-lg md:text-xl lg:text-2xl font-poppins text-foreground max-w-3xl mx-auto">
              Campanhas improvisadas acabam aqui. A Tconnecte apresenta um sistema inteligente de tráfego pago para
              negócios que desejam previsibilidade, crescimento e escala.
            </p>
          </div>
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-background hover:text-primary hover:border-primary border border-primary transition-colors font-poppins px-8 py-6 text-base rounded-md"
            onClick={() => window.open("https://wa.me/message/YOUR_WHATSAPP_NUMBER", "_blank")}
          >
            <MessageSquare className="mr-2 h-5 w-5" />
            Falar com a Tconnecte no WhatsApp
          </Button>
        </div>
      </div>
    </section>
  )
}

