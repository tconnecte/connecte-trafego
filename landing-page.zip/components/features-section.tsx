import { CheckCircle } from "lucide-react"

export default function FeaturesSection() {
  const features = [
    {
      title: "Fácil de usar",
      description: "Interface intuitiva que não requer conhecimento técnico avançado.",
      icon: CheckCircle,
    },
    {
      title: "Resultados rápidos",
      description: "Veja melhorias significativas em seu negócio em questão de semanas.",
      icon: CheckCircle,
    },
    {
      title: "Suporte dedicado",
      description: "Nossa equipe está sempre disponível para ajudar com qualquer dúvida.",
      icon: CheckCircle,
    },
    {
      title: "Atualizações constantes",
      description: "Novas funcionalidades são adicionadas regularmente sem custo adicional.",
      icon: CheckCircle,
    },
    {
      title: "Integração completa",
      description: "Conecte-se facilmente com as ferramentas que você já utiliza.",
      icon: CheckCircle,
    },
    {
      title: "Segurança avançada",
      description: "Seus dados estão protegidos com a mais alta tecnologia de criptografia.",
      icon: CheckCircle,
    },
  ]

  return (
    <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center justify-center space-y-4 text-center">
          <div className="space-y-2">
            <div className="inline-block rounded-lg bg-primary px-3 py-1 text-sm text-primary-foreground">Recursos</div>
            <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">
              Tudo que você precisa para crescer
            </h2>
            <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
              Nossa plataforma oferece todas as ferramentas necessárias para impulsionar seu negócio.
            </p>
          </div>
        </div>
        <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 pt-8 md:pt-12">
          {features.map((feature, index) => (
            <div key={index} className="flex flex-col items-center space-y-2 rounded-lg border p-4 bg-background">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">{feature.title}</h3>
              <p className="text-center text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

