import { BarChart3, Users, Target, TrendingUp } from "lucide-react"

export default function SolutionSection() {
  const pillars = [
    {
      icon: Target,
      title: "Estratégia Direcionada",
      description: "Tráfego planejado com base em dados e comportamento do seu público ideal.",
    },
    {
      icon: Users,
      title: "Audiência Qualificada",
      description: "Atração de pessoas realmente interessadas no que você oferece.",
    },
    {
      icon: BarChart3,
      title: "Métricas Claras",
      description: "Acompanhamento transparente de resultados e otimização contínua.",
    },
    {
      icon: TrendingUp,
      title: "Crescimento Sustentável",
      description: "Escalabilidade com retorno sobre investimento comprovado.",
    },
  ]

  return (
    <section className="w-full py-16 md:py-24 bg-secondary">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center">
          <div className="space-y-4 max-w-3xl">
            <h2 className="text-3xl md:text-4xl font-bold font-geoform text-foreground">Connecte Tráfego</h2>
            <p className="text-lg font-poppins text-foreground">
              Uma solução completa para transformar visitantes em clientes através de estratégias de tráfego
              inteligentes e direcionadas.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-8">
            {pillars.map((pillar, index) => (
              <div key={index} className="flex flex-col items-center space-y-3 p-6 bg-background rounded-lg">
                <div className="p-3 bg-secondary rounded-full">
                  <pillar.icon className="h-8 w-8 text-foreground" />
                </div>
                <h3 className="text-xl font-geoform font-medium text-foreground">{pillar.title}</h3>
                <p className="text-base font-poppins text-foreground">{pillar.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

