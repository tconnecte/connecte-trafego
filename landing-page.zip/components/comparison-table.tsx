import { Check, X } from "lucide-react"

export default function ComparisonTable() {
  const features = [
    {
      name: "Campanhas para seguidores",
      audience: true,
      combo: true,
    },
    {
      name: "Diagnóstico estratégico",
      audience: true,
      combo: true,
    },
    {
      name: "Captação de leads",
      audience: false,
      combo: true,
    },
    {
      name: "Nutrição de leads",
      audience: false,
      combo: true,
    },
    {
      name: "Ciclo mínimo",
      audience: "1 mês",
      combo: "6 meses",
    },
  ]

  return (
    <section className="w-full py-16 md:py-24 bg-background">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-geoform text-foreground">Tabela Comparativa</h2>
          <p className="text-lg font-poppins text-foreground max-w-3xl">
            Compare os planos e escolha a melhor opção para o seu negócio.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse max-w-3xl mx-auto">
            <thead>
              <tr className="border-b border-muted">
                <th className="py-4 px-6 text-left font-geoform text-foreground">Características</th>
                <th className="py-4 px-6 text-left font-geoform text-foreground">Audiência</th>
                <th className="py-4 px-6 text-left font-geoform text-foreground">Combo</th>
              </tr>
            </thead>
            <tbody>
              {features.map((feature, index) => (
                <tr key={index} className="border-b border-muted">
                  <td className="py-4 px-6 text-left font-poppins text-foreground">{feature.name}</td>
                  <td className="py-4 px-6 text-left font-poppins text-foreground">
                    {typeof feature.audience === "boolean" ? (
                      feature.audience ? (
                        <Check className="h-5 w-5 text-green-600" />
                      ) : (
                        <X className="h-5 w-5 text-red-500" />
                      )
                    ) : (
                      feature.audience
                    )}
                  </td>
                  <td className="py-4 px-6 text-left font-poppins text-foreground">
                    {typeof feature.combo === "boolean" ? (
                      feature.combo ? (
                        <Check className="h-5 w-5 text-green-600" />
                      ) : (
                        <X className="h-5 w-5 text-red-500" />
                      )
                    ) : (
                      feature.combo
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}

