export default function AboutSection() {
  return (
    <section className="w-full py-16 md:py-24 bg-secondary">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center">
          <div className="space-y-4 max-w-3xl">
            <h2 className="text-3xl md:text-4xl font-bold font-geoform text-foreground">O Que é o Connecte Tráfego</h2>
            <div className="text-lg font-poppins text-foreground space-y-4">
              <p>O Connecte Tráfego é um sistema estratégico de gestão de mídia paga.</p>
              <p>
                Com o método proprietário ARVE (Audiência, Relacionamento, Venda e Escala), validado em mais de 60
                projetos em 6 países, entregamos uma solução orientada por dados, método e performance real.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

