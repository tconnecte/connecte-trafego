"use client"

import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

export default function PricingSection() {
  const audiencePlan = {
    title: "Plano Audiência",
    price: "197€",
    description: "Foco em seguidores, branding e autoridade",
    features: [
      "Diagnóstico estratégico",
      "Ativação de Campanhas",
      "Foco em seguidores e branding",
      "Relatórios de performance",
    ],
  }

  const comboPlan = {
    title: "Combo Estratégico",
    subtitle: "Audiência + Relacionamento",
    price: "447€",
    discount: "com desconto de 13%",
    description: "Inclui captação de leads e estratégias de nutrição",
    features: [
      "Diagnóstico estratégico",
      "Isca Digital",
      "Segmentação Avançada",
      "Captação de leads",
      "Estratégias de nutrição",
      "Relatórios completos",
    ],
  }

  return (
    <section className="w-full py-16 md:py-24 bg-secondary">
      <div className="container px-4 md:px-6">
        <div className="flex flex-col items-center space-y-8 text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-geoform text-foreground">Planos Disponíveis</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Plano Audiência */}
          <div className="flex flex-col p-8 bg-white rounded-lg border border-muted shadow-sm h-full">
            <h3 className="text-2xl font-bold font-geoform text-foreground mb-2">{audiencePlan.title}</h3>
            <p className="text-foreground font-poppins mb-6">{audiencePlan.description}</p>
            <div className="mb-6">
              <span className="text-3xl font-bold font-geoform text-foreground">{audiencePlan.price}</span>
              <span className="text-foreground font-poppins">/mês</span>
            </div>
            <ul className="space-y-4 mb-8 flex-grow">
              {audiencePlan.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5 flex-shrink-0" />
                  <span className="font-poppins text-foreground">{feature}</span>
                </li>
              ))}
            </ul>
            <Button
              className="mt-auto bg-primary text-primary-foreground hover:bg-white hover:text-primary hover:border-primary border border-primary transition-colors font-poppins"
              onClick={() => window.open("https://wa.me/message/YOUR_WHATSAPP_NUMBER", "_blank")}
            >
              Contratar Plano Audiência
            </Button>
          </div>

          {/* Combo Estratégico */}
          <div className="flex flex-col p-8 bg-white rounded-lg border-2 border-primary shadow-md relative h-full">
            <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-4 py-1 text-sm font-poppins rounded-bl-lg">
              Recomendado
            </div>
            <h3 className="text-2xl font-bold font-geoform text-foreground mb-1">{comboPlan.title}</h3>
            <p className="text-lg font-medium font-geoform text-foreground mb-2">{comboPlan.subtitle}</p>
            <p className="text-foreground font-poppins mb-6">{comboPlan.description}</p>
            <div className="mb-6">
              <span className="text-3xl font-bold font-geoform text-foreground">{comboPlan.price}</span>
              <span className="text-foreground font-poppins">/mês</span>
              <p className="text-sm text-foreground/80 font-poppins mt-1">{comboPlan.discount}</p>
            </div>
            <ul className="space-y-4 mb-8 flex-grow">
              {comboPlan.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="h-5 w-5 text-primary mr-2 mt-0.5 flex-shrink-0" />
                  <span className="font-poppins text-foreground">{feature}</span>
                </li>
              ))}
            </ul>
            <Button
              className="mt-auto bg-primary text-primary-foreground hover:bg-white hover:text-primary hover:border-primary border border-primary transition-colors font-poppins"
              onClick={() => window.open("https://wa.me/message/YOUR_WHATSAPP_NUMBER", "_blank")}
            >
              Contratar Combo Estratégico
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}

