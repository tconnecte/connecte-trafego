import HeroSection from "@/components/hero-section"
import AboutSection from "@/components/about-section"
import DeliverablesSection from "@/components/deliverables-section"
import PricingSection from "@/components/pricing-section"
import ComparisonTable from "@/components/comparison-table"
import HowItWorks from "@/components/how-it-works"
import WhoIsItFor from "@/components/who-is-it-for"
import FaqSection from "@/components/faq-section"
import FinalCta from "@/components/final-cta"
import Footer from "@/components/footer"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <HeroSection />
      <AboutSection />
      <DeliverablesSection />
      <PricingSection />
      <ComparisonTable />
      <HowItWorks />
      <WhoIsItFor />
      <FaqSection />
      <FinalCta />
      <Footer />
    </div>
  )
}

